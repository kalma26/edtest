if crashed the game try to download and install the support file:
- Link: https://www.mediafire.com/file/xx88ddt2cupby2p/vc_redist_all_in_one.rar
- follow the instruction install
- run DechiperDX_Beta.exe and waiting to succeded
- if you have finished, play the game. thank you!